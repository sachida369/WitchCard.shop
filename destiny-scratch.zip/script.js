
document.getElementById('privacy').addEventListener('change', e => {
  document.getElementById('payBtn').disabled = !e.target.checked;
});

document.getElementById('payBtn').onclick = function (e) {
  e.preventDefault();
  const options = {
    key: "rzp_live_Hd6RirzluzFacK",
    amount: 1000,
    currency: "INR",
    name: "Destiny Scratch",
    description: "Unlock your fate",
    handler: function (response) {
      document.getElementById('userForm').style.display = 'none';
      document.querySelector('.card').style.display = 'block';
      getPrediction('girl');
    }
  };
  const rzp = new Razorpay(options);
  rzp.open();
};

async function getPrediction(gender) {
  const file = gender === 'boy' ? 'boys.json' : 'girls.json';
  const res = await fetch(file);
  const names = await res.json();
  const randomName = names[Math.floor(Math.random() * names.length)];
  document.querySelector('.prediction').innerText = `✨ ${randomName} ✨`;
}

document.getElementById('shareBtn').onclick = () => {
  const msg = encodeURIComponent("Check out my Destiny Scratch result! 🔮 Try yours here: https://yourwebsite.com");
  window.open(`https://wa.me/?text=${msg}`);
};

function downloadCard() {
  alert("Download function needs html2canvas to work fully.");
}
