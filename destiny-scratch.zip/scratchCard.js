
const canvas = document.getElementById('scratchCanvas');
const ctx = canvas.getContext('2d');
canvas.width = 100;
canvas.height = 100;
ctx.fillStyle = '#ccc';
ctx.fillRect(0, 0, 100, 100);
canvas.addEventListener('mousemove', function (e) {
  if (e.buttons !== 1) return;
  const rect = canvas.getBoundingClientRect();
  const x = e.clientX - rect.left;
  const y = e.clientY - rect.top;
  ctx.clearRect(x - 10, y - 10, 20, 20);
});
